from django.urls import path

from . import views

urlpatterns = [
    path('', views.give_view, name='give_view'),
    path('check/', views.sl_check, name='sl_check'),
]

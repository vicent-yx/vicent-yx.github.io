from selenium import webdriver
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome()
driver.get('https://box3.fun/e/a5d1cfd982743e3a146f')
driver.find_element(By.XPATH,r'/html/body/div[2]/div/div[3]/div[3]/button').click()
time.sleep(5000)
driver.close()
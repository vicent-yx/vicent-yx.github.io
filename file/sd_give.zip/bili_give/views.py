from contextlib import nullcontext
from unicodedata import name
from django.http import HttpResponse
from django.shortcuts import render

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import requests
import json

# Create your views here.
def give_view(request):
    return render(request,'give_view.html')

def sl_check(request):
    uid = request.GET["uid"]
    t_key = request.GET["key"]
    cookie = None#此处为cookies，需要把从开发者工具复制的cookies转化为字典格式粘贴到这里
    xx = requests.get("https://api.bilibili.com/x/msgfeed/like_detail?card_id=70469944441&last_view_at=0&pn=1&build=0&mobi_app=web",cookies=cookie)
    data = json.loads(xx.text)
    like_list = data["data"]["items"]
    for liker in like_list:
        if(str(liker["user"]["mid"]) == str(uid)):
            with open("pay_data.json","r",encoding="utf-8")as f:
                pay_data = json.load(f)
            print(pay_data)
            for data in pay_data:
                if data[0] == uid or data[1] == t_key and pay_data != []:
                    return render(request,'biliGive_fail.html')
            pay_data.append([uid,t_key])
            with open("pay_data.json","w")as f:
                json.dump(pay_data,f)
            driver = webdriver.Chrome()
            driver.get('https://box3.fun/e/5cbf6b34c7b01ded0d65?admin=vicent666&key='+str(t_key))
            driver.find_element(By.XPATH,r'/html/body/div[2]/div/div[3]/div[3]/button').click()
            time.sleep(5)
            driver.close()
            return render(request,'biliGive_success.html')
    return render(request,'biliGive_fail.html')
from unicodedata import name
from django.http import HttpResponse
from django.shortcuts import render

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import requests
import json

# Create your views here.
def give_view(request):
    return render(request,'give_view.html')

def sl_check(request):
    uid = request.GET["uid"]
    t_key = request.GET["key"]
    cookie = {'_uuid': '351037924-71D4-523F-14AC-B63D924D6610232438infoc', 'buvid3': 'DEB44CB6-BFE7-9A60-5CD8-9784B9D5A46431173infoc', 'b_nut': '1644071533', 'buvid4': '795BC860-72EC-F19F-1CAA-69D6E99150A331173-022020522-c8mC4VtaIp818bJ7HB6WVw%3D%3D', 'buvid_fp': 'c85acecdec1982f466b143f7734a5dd6', 'PVID': '1', 'CURRENT_FNVAL': '4048', 'blackside_state': '1', 'rpdid': "|(k|k)Y)m|JR0J'uYRR|~ulRk", 'i-wanna-go-back': '-1', 'b_ut': '5', 'fingerprint': 'c85acecdec1982f466b143f7734a5dd6', 'sid': 'alj8mz31', 'buvid_fp_plain': 'undefined', 'SESSDATA': '9a95d7b6%2C1672047096%2C365e2%2A61', 'bili_jct': 'e96b798392c89e8e80a415c053216306', 'DedeUserID': '488522677', 'DedeUserID__ckMd5': '01839e13c0f4ee44', 'hit-dyn-v2': '1', 'innersign': '0', 'b_lsid': 'EC2C818C_181B25C5A2A', 'b_timer': '%7B%22ffp%22%3A%7B%22333.1007.fp.risk_DEB44CB6%22%3A%22181B25C62DA%22%7D%7D'}
    xx = requests.get("https://api.bilibili.com/x/msgfeed/like_detail?card_id=70469944441&last_view_at=0&pn=1&build=0&mobi_app=web",cookies=cookie)
    data = json.loads(xx.text)
    like_list = data["data"]["items"]
    for liker in like_list:
        if(str(liker["user"]["mid"]) == str(uid)):
            with open("pay_data.json","r",encoding="utf-8")as f:
                pay_data = json.load(f)
            print(pay_data)
            for data in pay_data:
                if data[0] == uid or data[1] == t_key and pay_data != []:
                    return render(request,'biliGive_fail.html')
            pay_data.append([uid,t_key])
            with open("pay_data.json","w")as f:
                json.dump(pay_data,f)
            driver = webdriver.Chrome()
            driver.get('https://box3.fun/e/5cbf6b34c7b01ded0d65?admin=vicent666&key='+str(t_key))
            driver.find_element(By.XPATH,r'/html/body/div[2]/div/div[3]/div[3]/button').click()
            time.sleep(5)
            driver.close()
            return render(request,'biliGive_success.html')
    return render(request,'biliGive_fail.html')